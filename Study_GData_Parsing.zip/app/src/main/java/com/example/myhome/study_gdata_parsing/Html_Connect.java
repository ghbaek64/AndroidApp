package com.example.myhome.study_gdata_parsing;

import org.jsoup.Jsoup;
import org.jsoup.select.Elements;

/**
 * Created by Myhome on 2016-07-22.
 */
public class Html_Connect extends Thread {
    String url;
    String result;
    public Html_Connect(String url){
        this.url = url;
    }
    @Override
    public void run() {
        final String output = request(url);
        result = output;
    }

    public String getResult(){
        return result;
    }

    private String request(String url) {

        try {
            org.jsoup.nodes.Document document = Jsoup.connect(url).get();

            Elements elements = document.select("ul.weekList > li > a > img");

            for (int i = 0; i < elements.size(); i++) {
                result += elements.get(i).attr("alt") + "\n";
            }
            getResult();
            return result;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
