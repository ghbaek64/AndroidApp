package com.example.myhome.study_gdata_parsing;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.jsoup.select.Elements;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.io.ByteArrayInputStream;
import java.io.InputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.jsoup.Jsoup;



public class MainActivity extends AppCompatActivity {
    boolean sw_xml,sw_json,sw_html;
    String read_data;
    TextView tv_first_result,tv_stat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btn_xml_read = (Button)findViewById(R.id.btn_xml_read);
        Button btn_json_read = (Button)findViewById(R.id.btn_json_read);
        Button btn_html_read = (Button)findViewById(R.id.btn_html_read);
        Button btn_xml_parsing = (Button)findViewById(R.id.btn_xml_parsing);
        Button btn_json_parsing = (Button)findViewById(R.id.btn_json_parsing);

        tv_first_result = (TextView) findViewById(R.id.tv_firstOutput);
        tv_stat = (TextView)findViewById(R.id.tv_stat);

        sw_xml = false; sw_json = false; sw_html = false;

        assert btn_xml_read != null;
        assert btn_xml_parsing != null;

        btn_xml_read.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String serviceKey = "GYAlMFriZSU2nethDlfy8lH5Wfz5sEmePM1wp6SSzvjrUFX%2FzY%2F2LZV6efOhbYYtVbppS%2Fj9SMCFO3PFU%2FNdqQ%3D%3D";
                String numOfRows = "5";
                String pageSize = "10";
                String pageNo = "1";
                String idx = "221112";
                String date = "2017072005";
                String xml_URL = "http://opendata.busan.go.kr/openapi/service/AirQualityInfoService/getAirQualityInfoClassifiedByStation?ServiceKey="+ serviceKey +"&numOfRows="+ numOfRows +"&pageSize="+ pageSize +"&pageNo="+ pageNo +"&idx="+ idx +"&Date_hour=" + date;

                Connect connect = new Connect(xml_URL);
                Toast.makeText(MainActivity.this, "waiting... for result", Toast.LENGTH_SHORT).show();

                connect.start();
                try{
                    connect.join();
                }
                catch(InterruptedException e){
                    Log.d("오류", "메인 오류");
                }

                read_data = connect.getResult();
                Log.d("Reading data", connect.getResult());
                tv_first_result.setText(connect.getResult());
                tv_stat.setText("status : XML Data Read");
                //값을 읽어왔으면 parsing 이벤트를 시작할 수 있게
                sw_xml =true;
            }
        });

        assert btn_json_read != null;
        btn_json_read.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String json_URL = "http://byeonghoon.dothome.co.kr/android_project/transfer_select.php";
                Connect connect = new Connect(json_URL);

                Toast.makeText(MainActivity.this, "waiting... for result", Toast.LENGTH_SHORT).show();

                connect.start();
                try{
                    connect.join();
                }
                catch(InterruptedException e){
                    Log.d("오류", "메인 오류");
                }

                read_data = connect.getResult();
                Log.d("Reading data", connect.getResult());
                tv_first_result.setText(connect.getResult());
                tv_stat.setText("status : JSON Data Read");
                //값을 읽어왔으면 parsing 이벤트를 시작할 수 있게
                sw_json =true;
            }
        });

        assert btn_html_read != null;
        btn_html_read.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tv_first_result.setText("");

                Html_Connect html_connect = new Html_Connect("http://www.leagueoflegends.co.kr");

                html_connect.start();

                try{
                   html_connect.join();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                tv_first_result.setText(html_connect.getResult());

                tv_stat.setText("status : HTML Data Read");
                //값을 읽어왔으면 parsing 이벤트를 시작할 수 있게

            }
        });

        btn_xml_parsing.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(sw_xml){
                    tv_first_result.setText("");
                    xml_parse(read_data);
                    sw_xml = false;
                    tv_stat.setText("status : XML Data Parsing");
                }
                else{
                    Toast.makeText(MainActivity.this, "먼저 xml 데이터를 읽어오세요.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        assert btn_json_parsing != null;
        btn_json_parsing.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(sw_json){
                    tv_first_result.setText("");
                    json_parse(read_data);
                    sw_json = false;
                    tv_stat.setText("status : JSON Data Parsing");
                }
                else{
                    Toast.makeText(MainActivity.this, "먼저 json 데이터를 읽어오세요.", Toast.LENGTH_SHORT).show();
                }
            }
        });



    }
    public void xml_parse(String data){

        try{
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder documentBuilder = factory.newDocumentBuilder();

            //xml을 InputStream형태로 변환
            InputStream is = new ByteArrayInputStream(data.getBytes());

            //document와 element 는 w3c dom에 있는것을 임포트 한다.
            Document doc = documentBuilder.parse(is);

            Element element = doc.getDocumentElement();
            //읽어올 태그명 정하기

            NodeList items = element.getElementsByTagName("pm10");
            //읽어온 자료의 수

            int n = items.getLength();
            //자료를 누적시킬 stringBuffer 객체

            StringBuffer sBuffer = new StringBuffer();
            //반복문을 돌면서 모든 데이터 읽어오기

            for(int i=0 ; i < n ; i++){
                //읽어온 자료에서 알고 싶은 문자열의 인덱스 번호를 전달한다.

                Node item = items.item(i);
                Node text = item.getFirstChild();
                //해당 노드에서 문자열 읽어오기

                String itemValue = text.getNodeValue();

                sBuffer.append("pm10 :"+itemValue+"\r\n");
            }
            //읽어온 문자열 출력해보기
            tv_first_result.setText(sBuffer.toString());

        }catch (Exception e) {
            Log.e("파싱 중 에러 발생", e.getMessage());
        }

    }

    public void json_parse(String data){
        try{
            JSONObject root = new JSONObject(data);

            JSONArray ja = root.getJSONArray("result");

            for(int i = 0; i < ja.length();i++)
            {
                JSONObject jo = ja.getJSONObject(i);
                tv_first_result.setText(tv_first_result.getText() + jo.getString("student_name"));
            }
        }

        catch(JSONException e){
            e.printStackTrace();
        }
    }
}
