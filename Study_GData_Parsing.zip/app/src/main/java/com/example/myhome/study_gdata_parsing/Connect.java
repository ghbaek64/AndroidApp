package com.example.myhome.study_gdata_parsing;

import android.util.Log;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;


/**
 * Created by Myhome on 2016-07-22.
 */
public class Connect extends Thread {
    private String result;
    private String url;

    public Connect(String url){
        this.url = url;
    }
    @Override
    public void run() {
        final String output = request(url);
        result = output;
    }
    public String getResult(){
        return result;
    }
    private String request(String urlStr) {

        StringBuffer sBuffer = new StringBuffer();

        try {
            URL url = new URL(urlStr);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            if (conn != null) {
                conn.setConnectTimeout(20000);
                conn.setUseCaches(false);
                if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    //서버에서 읽어오기 위한 스트림 객체
                    InputStreamReader isr = new InputStreamReader(conn.getInputStream());
                    //줄단위로 읽어오기 위해 BufferReader로 감싼다.
                    BufferedReader br = new BufferedReader(isr);
                    //반복문 돌면서읽어오기
                    while (true) {
                        String line = br.readLine();
                        if (line == null) {
                            break;
                        }
                        sBuffer.append(line);
                    }
                    br.close();
                    conn.disconnect();
                }
            }

            //결과값 출력해보기

            //editText.setText(sBuffer.toString());

            return sBuffer.toString(); //결과값 변수에 담기

        } catch (Exception e) {

            // TODO: handle exception

            Log.e("다운로드 중 에러 발생", e.getMessage());
            return null;
        }
    }
}

